use strict;
use warnings;

package Test::WithCallback;
use App::Cmd::Setup -app;

1;
