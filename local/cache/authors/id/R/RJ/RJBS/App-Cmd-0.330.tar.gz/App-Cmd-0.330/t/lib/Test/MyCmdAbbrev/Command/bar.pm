package Test::MyCmdAbbrev::Command::bar;

use strict;
use warnings;

use base qw{ App::Cmd::Command };

1;
