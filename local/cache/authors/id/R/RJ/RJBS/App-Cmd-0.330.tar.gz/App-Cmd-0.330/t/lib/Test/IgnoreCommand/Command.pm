use strict;
use warnings;

package Test::IgnoreCommand::Command;

use Test::IgnoreCommand -ignore;

sub foo {
  return "hi";
}


1;
